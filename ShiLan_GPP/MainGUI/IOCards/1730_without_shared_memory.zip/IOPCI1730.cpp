#include "StdAfx.h"
#include "IOPCI1730.h"
#include "SharedMemory.h"

CIOPCI1730::CIOPCI1730(void)
{

	m_bSemDeviceStatus = FALSE;
	m_hSempDevice = CreateSemaphore(NULL, 0, 1, CString("_IOPCI1730_SEMAPHORE"));//�����豸ռ���ź���
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		m_bSemDeviceStatus = TRUE;
	}

	m_hIOEvts[eIOExit] = CreateEvent(NULL,TRUE,FALSE,NULL);  // Manual reset active event
	m_hIOEvts[eIOInt] = CreateEvent(NULL,FALSE,FALSE,NULL);  // Manual reset active event
	m_hWaitOutput = CreateEvent(NULL, TRUE, TRUE, NULL);//�����豸����¼�


	//m_Teachstatus = E_WAITING;
	//tickSot = 0;
	
}

CIOPCI1730::~CIOPCI1730(void)
{
}

BOOL CIOPCI1730::Open(LPVOID pParam)
{

	BOOL bResult = FALSE;

	/* if (pParam)
	{
		m_nCardNumber = (short)pParam;
	}
	else
	{
		m_nCardNumber = -1;
	} */
	
	m_nCardNumber = (short)pParam;
	
	DeviceInformation    devInfo(m_nCardNumber);
	m_instantDoCtrl = InstantDoCtrl::Create();
	m_instantDiCtrl = InstantDiCtrl::Create();
    m_errorCode = m_instantDiCtrl->setSelectedDevice(devInfo);
    if(m_errorCode != 0)
	{
		return FALSE;
	}
	m_errorCode = m_instantDoCtrl->setSelectedDevice(devInfo);
    if(m_errorCode != 0)
	{
		return FALSE;
	}

	m_pThread = AfxBeginThread(fnThread,this,THREAD_PRIORITY_ABOVE_NORMAL,0,0,NULL);
	//SetOpenFlag(bResult);
	return TRUE;
}
 

BOOL CIOPCI1730::Close()
{
	//�ͷ��ж���Դ
	

	if ( m_pThread&&m_pThread->m_hThread)
	{
		::SetEvent(m_hIOEvts[eIOExit]);
		::WaitForSingleObject(m_pThread->m_hThread,INFINITE);
		m_pThread = NULL;
	}

	//if (!IsOpened() ) return TRUE;

	// �ر��豸,��ֹ����,���ͷ���Դ
	//PCI2312_ReleaseDevice(m_hDevice);

	//SetOpenFlag(FALSE);
	::CloseHandle(m_hIOEvts[eIOExit]);
	::CloseHandle(m_hIOEvts[eIOInt]);
	if(m_bSemDeviceStatus == FALSE)
	{

		if(m_instantDoCtrl != NULL)
		{
			m_instantDoCtrl->Dispose();
		}
		if(m_instantDiCtrl != NULL)
		{
			m_instantDiCtrl->Dispose();
		}
	}

	return TRUE;
}

//input
DWORD64 CIOPCI1730::GetInputValue()
{

		uint8 data[2];//�������Ĵ�СӦ��m_nPortCountֵ��ͬ
		m_errorCode = m_instantDiCtrl->Read(m_nStartPort, m_nPortCount, data);
		if(m_errorCode != 0 )
		{
			return -1;
		}
		int data1Value = data[0];
		int data2Value = data[1];
		data2Value = data2Value << 8;
		DWORD64 v = data1Value +data2Value; 
		return v;
}

//output
BOOL CIOPCI1730::SetOutputValue(DWORD64 v)
{
		::ResetEvent(m_hWaitOutput);
		uint8 data[2];//�������Ĵ�СӦ��m_nPortCountֵ��ͬ
		

		data[0] = (v & 0x00FF);
		data[1] = ((v & 0xff00) >> 8);

		m_errorCode = m_instantDoCtrl->Write(m_nStartPort, m_nPortCount, data);

		
		::SetEvent(m_hWaitOutput);
		if(m_errorCode != 0)
		{
			return FALSE;
		}
		return TRUE;
}

//for simulation
void CIOPCI1730::GenerateSOT(INT nIntNo)
{
	//::SetEvent(m_hNotifyEvt[nIntNo]);
// 	if (nIntNo == 0)
// 	{
// 		CIOProtocol* pIOProtocol = GetIOProtocol();
// 		if ( !pIOProtocol ) return;
// 
// 		CStationContainer*	pStationArray = pIOProtocol->GetStationContainer();
// 		//
// 		//Send event to start individual inspection
// 		//
// 		for (int i=0; i<pStationArray->GetCount(); i++)
// 		{
// 			CWorkstation* pStation = pStationArray->GetAt(i);
// 			pStation->SetActiveEvent();
// 		}
// 	}
// 
// 	if (nIntNo == 1)
// 	{
// 		tickCountSend = ::GetTickCount();
// 	}
}

UINT CIOPCI1730::fnThread(LPVOID pParam)
{
	CIOPCI1730* pIOCard = (CIOPCI1730*)pParam;
	DWORD	dwRetVal;
	DWORD   dwPauseSignal;

	::Sleep(2000);
	DWORD64 preInput = pIOCard->GetInputValue();
	DWORD tickCount = GetTickCount(); //���һ�μ�鵽IO�仯��ʱ��

	while(TRUE)
	{
		dwRetVal = ::WaitForMultipleObjects( 2, pIOCard->m_hIOEvts, FALSE, 1);
		dwPauseSignal = ::WaitForSingleObject(pIOCard->m_hWaitOutput, 0);
		//E_STATUS preStatus = pIOCard->m_status;
		DWORD tickCountRev = GetTickCount();

		if ( dwRetVal == WAIT_OBJECT_0 + eIOExit )
		{
			break;
		}
		else
		{
			if (dwRetVal==WAIT_OBJECT_0 + eIOInt)
			{
				//AfxMessageBox("test");
				//ZT8408_ClearIRQ(pIOCard->m_nCardNumber,0xFF);
			}

			//
			//Send event to individual station to start inspection 
			//
			DWORD64 dwInput = pIOCard->GetInputValue();

			DWORD64 changeInput = (preInput^dwInput);
			//DWORD64 changeInput = (preInput^dwInput)&preInput;

			if (changeInput)
			{
				pIOCard->SendEventToIndividualStation( dwInput );
				tickCount = ::GetTickCount();
			}
			else if (::GetTickCount()-tickCount>100) //���IO��ʱ��û�б仯Ҳ��ͼ����
			{
				pIOCard->SendEventToIndividualStation( dwInput );
				tickCount = ::GetTickCount();
			}

			preInput = dwInput;
		}

		//		::Sleep(0);
	}

	TRACE(_T("CIOPCI8408::fnThread exited!\n"));

	return 0;
}

void CIOPCI1730::SendEventToIndividualStation(DWORD64 dwInput)
{
//	CIOProtocol* pIOProtocol = GetIOProtocol();
//	if ( !pIOProtocol) return;

// 	CStationContainer*	pStationArray = pIOProtocol->GetStationContainer();
// 	CWorkstation*		pStation;

	//
	//Send event to start individual inspection
	//
// 	for (int i=0; i<pStationArray->GetCount(); i++)
// 	{
// 		pStation = pStationArray->GetAt(i);
// 		if (pStation == NULL)
// 		{
// 		}
// 		else pStation->TestStartSingal(dwInput);
// 	}
}




void CIOPCI1730::SetStartPort(int port)
{
	m_nStartPort = port;
}

void CIOPCI1730::SetPortCount(int count)
{
	m_nPortCount = count;
}
