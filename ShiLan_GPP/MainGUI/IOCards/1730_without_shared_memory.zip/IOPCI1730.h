#pragma once

#include "bdaqctrl.h"

using namespace Automation::BDaq;

//typedef enum
//{
//	E_WAITING,
//	END_INSPECTION,
//	GRAB_PIC,
//	OPEN_LEARN,
//	END_TEACH,
//} E_STATUS;



class CIOPCI1730
{
public:
	CIOPCI1730(void);
	~CIOPCI1730(void);

	virtual BOOL Open(LPVOID pParam=NULL);
	virtual BOOL Close();

	//input
	virtual DWORD64 GetInputValue();

	//output
	virtual BOOL SetOutputValue(DWORD64 v);

	//for simulation
	virtual void GenerateSOT(INT nIntNo);
protected:
	static UINT fnThread(LPVOID pParam);

	virtual void SendEventToIndividualStation(DWORD64 dwInput);



public:
	//E_STATUS m_Teachstatus;
	//DWORD tickSot;

protected:
	SHORT	m_nCard;
	SHORT	m_nCardNumber;
	InstantDiCtrl *m_instantDiCtrl;
	InstantDoCtrl *m_instantDoCtrl;
	ErrorCode m_errorCode;

	CWinThread*		m_pThread;

	int m_nStartPort;
	int m_nPortCount;
	
	

	enum IOEvtType {eIOExit,eIOInt,eNumIOInts };
	HANDLE	m_hIOEvts[eNumIOInts];
	HANDLE m_hWaitOutput; 
	HANDLE m_hDevice;

	BOOL m_bSemDeviceStatus;
	HANDLE m_hSempDevice;



	//CTimeMeasure m_tmMeasure;
	DWORD tickCountSend;
	int RollingWard;
public:
	void SetStartPort(int port);
	void SetPortCount(int count);
};
